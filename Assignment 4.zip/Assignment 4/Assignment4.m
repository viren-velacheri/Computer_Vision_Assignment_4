% Assignment 4
% Name: Viren Velacheri, EID: vv6898
% Slip days: 2

% The general set up where just loading in the images. Got the height and
% width for combining the two images together for my ginput set up that
% appears later. 

sourcePicture = "SourceImage.jpg";
sourceImage = imread(sourcePicture);
targetPicture = "TargetImage.jpg";
targetImage = imread(targetPicture);


% This is my first set of feature correspondences and the one that I 
% generated the Essential matrix and Rotation and translation matrices
% in the previous questions. In the pdf, I go into detail about why I 
% think this was configuration of points was the best from the 5 or 6 that
% I toyed with. I used ginput to pick out 8 points from each image (source
% and target) manually. I just looked at the image in pdf and tried to
% pick out similar points.
[height2, width2, ~] = size(targetImage);
[height, width, ~] = size(sourceImage);
newImage = cat(2, sourceImage, targetImage);
figure; ax = axes;
imshow(newImage);
hold on;
numPoints = 8;
[x, y] = ginput(numPoints);
sCoord2D = [x y];
sCoord2D = sCoord2D';
imshow(newImage);
hold on;
for i=1:numPoints
    yCoord = sCoord2D(2, i);
    xCoord = sCoord2D(1, i);
    line([xCoord, width + width2], [yCoord, yCoord]);
end
plot(x, y, 'ro');
[x2, y2] = ginput(numPoints);
tCoord2D = [x2 y2];
tCoord2D = tCoord2D';
imshow(newImage);
hold on;
for i=1:numPoints
    yCoord2 = tCoord2D(2, i);
    xCoord2 = tCoord2D(1, i);
    yCoord = sCoord2D(2, i);
    xCoord = sCoord2D(1, i);
    line([xCoord, xCoord2], [yCoord, yCoord2]);
end
plot(x, y, 'ro');
plot(x2, y2, 'g+');
title(ax, 'The 1st Set of Feature Correspondences');
K = [3236.45 -83.52 2160.43; 0 3246.00 1106.04; 0 0 1];
% K = [2700.9 155.268 2067.1; 0 2319.6 273.26; 0 0 1]; My K matrix
[R, T] = relativepose(sCoord2D, tCoord2D, K);


% This is my second set of feature correspondences. I use the detect harris
% features method and basically the set of 8 points from each image
% that match up to one another and those are my feature correspondences.
% The K matrix I use is the one given by the TA. Even though my K matrix
% the one in a comment, does work for a lot of them, I felt it was not as
% consistent and hence that is why I switched to using this other K matrix
% instead. 
numPoints = 8;
points1 = detectHarrisFeatures(rgb2gray(sourceImage));
points2 = detectHarrisFeatures(rgb2gray(targetImage));
[f1, vpts1] = extractFeatures(rgb2gray(sourceImage), points1);
[f2, vpts2] = extractFeatures(rgb2gray(targetImage), points2);
indexPairs = matchFeatures(f1, f2);
matchedPoints1 = vpts1(indexPairs(1:numPoints, 1));
matchedPoints2 = vpts2(indexPairs(1:numPoints, 2));
figure; ax = axes;
showMatchedFeatures(sourceImage,targetImage,matchedPoints1,matchedPoints2,'montage','Parent',ax);
title(ax, 'The 2nd Set of Feature Correspondences');
legend(ax, 'Source Image Points','Target Image Points');
K = [3236.45 -83.52 2160.43; 0 3246.00 1106.04; 0 0 1];
% K = [2700.9 155.268 2067.1; 0 2319.6 273.26; 0 0 1]; My K matrix
sCoord2D = matchedPoints1.Location'; % The set of source feature points
tCoord2D = matchedPoints2.Location'; % The set of target feature points
[R, T] = relativepose(sCoord2D, tCoord2D, K);



% This is my third set of feature correspondences. Here instead of using
% the Harris features method, I used the minimum Eigen value algorithm
% to detect the set of feature correspondences. 
numPoints = 10;
points1 = detectMinEigenFeatures(rgb2gray(sourceImage));
points2 = detectMinEigenFeatures(rgb2gray(targetImage));
[f1, vpts1] = extractFeatures(rgb2gray(sourceImage), points1);
[f2, vpts2] = extractFeatures(rgb2gray(targetImage), points2);
indexPairs = matchFeatures(f1, f2);
matchedPoints1 = vpts1(indexPairs(1:numPoints, 1));
matchedPoints2 = vpts2(indexPairs(1:numPoints, 2));
figure; ax = axes;
showMatchedFeatures(sourceImage,targetImage,matchedPoints1,matchedPoints2,'montage','Parent',ax);
title(ax, 'The 3rd Set of Feature Correspondences');
legend(ax, 'Source Image Points','Target Image Points');
K = [3236.45 -83.52 2160.43; 0 3246.00 1106.04; 0 0 1];
% K = [2700.9 155.268 2067.1; 0 2319.6 273.26; 0 0 1]; My K matrix
sCoord2D = matchedPoints1.Location'; % The set of source feature points
tCoord2D = matchedPoints2.Location'; % The set of target feature points
[R, T] = relativepose(sCoord2D, tCoord2D, K);



% This is my fourth set of feature correspondences. I once again use the
% minimum Eigen Value algorithm to detect the set of feature
% correspondences. This time, I just use more points.
numPoints = 14;
points1 = detectMinEigenFeatures(rgb2gray(sourceImage));
points2 = detectMinEigenFeatures(rgb2gray(targetImage));
[f1, vpts1] = extractFeatures(rgb2gray(sourceImage), points1);
[f2, vpts2] = extractFeatures(rgb2gray(targetImage), points2);
indexPairs = matchFeatures(f1, f2);
matchedPoints1 = vpts1(indexPairs(1:numPoints, 1));
matchedPoints2 = vpts2(indexPairs(1:numPoints, 2));
figure; ax = axes;
showMatchedFeatures(sourceImage,targetImage,matchedPoints1,matchedPoints2,'montage','Parent',ax);
title(ax, 'The 4th Set of Feature Correspondences');
legend(ax, 'Source Image Points','Target Image Points');
K = [3236.45 -83.52 2160.43; 0 3246.00 1106.04; 0 0 1];
% K = [2700.9 155.268 2067.1; 0 2319.6 273.26; 0 0 1]; My K matrix
sCoord2D = matchedPoints1.Location'; % The set of source feature points
tCoord2D = matchedPoints2.Location'; % The set of target feature points
[R, T] = relativepose(sCoord2D, tCoord2D, K);



% This is my fifth set of feature correspondences. I once again use the
% minimum Eigen Value algorithm to detect the set of feature
% correspondences. This time, I just use more points.
numPoints = 16;
points1 = detectMinEigenFeatures(rgb2gray(sourceImage));
points2 = detectMinEigenFeatures(rgb2gray(targetImage));
[f1, vpts1] = extractFeatures(rgb2gray(sourceImage), points1);
[f2, vpts2] = extractFeatures(rgb2gray(targetImage), points2);
indexPairs = matchFeatures(f1, f2);
matchedPoints1 = vpts1(indexPairs(1:numPoints, 1));
matchedPoints2 = vpts2(indexPairs(1:numPoints, 2));
figure; ax = axes;
showMatchedFeatures(sourceImage,targetImage,matchedPoints1,matchedPoints2,'montage','Parent',ax);
title(ax, 'The 5th Set of Feature Correspondences');
legend(ax, 'Source Image Points','Target Image Points');
K = [3236.45 -83.52 2160.43; 0 3246.00 1106.04; 0 0 1];
% K = [2700.9 155.268 2067.1; 0 2319.6 273.26; 0 0 1]; My K matrix
sCoord2D = matchedPoints1.Location'; % The set of source feature points
tCoord2D = matchedPoints2.Location'; % The set of target feature points
[R, T] = relativepose(sCoord2D, tCoord2D, K);


% This is my 6th (extra) set of feature correspondences. This time I use
% the BRISK features algorithm where the keypoints are
% Binary Robust Invariant Scalable. Pretty interesting so that is why 
% I did this as well.
numPoints = 11;
points1 = detectBRISKFeatures(rgb2gray(sourceImage));
points2 = detectBRISKFeatures(rgb2gray(targetImage));
[f1, vpts1] = extractFeatures(rgb2gray(sourceImage), points1);
[f2, vpts2] = extractFeatures(rgb2gray(targetImage), points2);
indexPairs = matchFeatures(f1, f2);
matchedPoints1 = vpts1(indexPairs(1:numPoints, 1));
matchedPoints2 = vpts2(indexPairs(1:numPoints, 2));
figure; ax = axes;
showMatchedFeatures(sourceImage,targetImage,matchedPoints1,matchedPoints2,'montage','Parent',ax);
title(ax, 'The 6th (Extra) Set of Feature Correspondences');
legend(ax, 'Source Image Points','Target Image Points');
K = [3236.45 -83.52 2160.43; 0 3246.00 1106.04; 0 0 1];
% K = [2700.9 155.268 2067.1; 0 2319.6 273.26; 0 0 1]; My K matrix
sCoord2D = matchedPoints1.Location'; % The set of source feature points
tCoord2D = matchedPoints2.Location'; % The set of target feature points
[R, T] = relativepose(sCoord2D, tCoord2D, K);