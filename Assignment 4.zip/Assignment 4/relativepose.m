% This function takes the feature correspondences as input or the selected
% points from source and target images and then also takes in K or the
% intrinsic camera parameters as input as well. Even though the Essential
% matrix is computed, the actual output or what is returned are the 
% Rotation and Translation matrices which are extracted from the esential
% matrix.
function [R, T] = relativepose(sCoord2D, tCoord2D, K)
numPoints = size(sCoord2D,2); % The number of points
% The below is done to convert the pixel coordinates to camera coordinates.
% This is straight from the slides/notes we went over in class. 
cameraCoord1 = inv(K) * [sCoord2D; ones(1, numPoints)];
cameraCoord2 = inv(K) * [tCoord2D; ones(1, numPoints)];
% This is where the computation for the A matrix is done.
% It will be a N by 9 matrix where N is the number of
% feature correspondences picked.
A = [];
for i=1:numPoints
    x1 = cameraCoord1(1, i);
    y1 = cameraCoord1(2, i);
    z1 = cameraCoord1(3, i);
    x2 = cameraCoord2(1, i);
    y2 = cameraCoord2(2, i);
    z2 = cameraCoord2(3, i);
    % The row is computed based on the formula in notes
    row = [x2 * x1, x2 * y1, x2 * z1, y2 * x1, y2 * y1, y2 * z1, z2 * x1, z2 * y1, z2 * z1];
    A = [A; row];
end
% Singular value decomposition is done here to get V
% From here e is found by getting the 9th column here. 
% It is then reshaped to get the estimated E matrix.
[~, ~, V] = svd(A);
e = V(:, 9);
E = reshape(e, [3, 3])';
% The Singular value decomposition is done again and, from testing and 
% seeing that diagonal from top left to bottom right has to be 1 1 0, 
% I then recompute E by multiplying the U and V' by this to get my 
% new Essential matrix.
[U, ~, V] = svd(E);
S = [1 0 0; 0 1 0; 0 0 0];
newE = U * S * V';
negTheta = -pi/2;
theta = pi/2;
% These are the rotation matrices in the Z direction that are used to 
% computed the Rotation matrices.
rz = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
rzNeg = [cos(negTheta) -sin(negTheta) 0; sin(negTheta) cos(negTheta) 0; 0 0 1];
RPos = U * rz' * V';
RNeg = U * rzNeg' * V';

% The determinant is either 1 or -1. If 1, actualE is set to the positive 
% version of E. Otherwise, set to negative version of it.
if det(RPos) == 1 && det(RNeg) == 1
    actualE = newE;
else 
    actualE = -newE;
end

% SVD is again done to get the U and V
% The two possibilities of R and T hat matrices are then computed.
[U, ~, V] = svd(actualE);
RPos = U * rz' * V';
TPos = U * rz * S * U';
RNeg = U * rzNeg' * V';
TNeg = U * rzNeg * S * U';

THat = TPos; % This is for later when computing E - THat * R for see how
% accurate the results are. 
% Since my T hat is skew matrix, can now extract values for possible
% T matrices.
realTPos = [TPos(3, 2); TPos(1, 3); TPos(2, 1)];
realTNeg = [TNeg(3, 2); TNeg(1, 3); TNeg(2, 1)];

posLambdas = [];
i = 1;
stillPositive = true;
% This is done for seeing where as long as the computed lambdas for each
% point are positive, continue through the set of points. If have gone
% through all the points and all lambda values positive, then right
% configuration of R and T has been found.
while i <= numPoints && stillPositive 
    % A and b are computed based on formulaes in notes.
    A = [RPos * cameraCoord1(:, i), -1 * cameraCoord2(:, i)]' * [RPos * cameraCoord1(:, i), -1 * cameraCoord2(:, i)];
    b = [RPos * cameraCoord1(:, i), -1 * cameraCoord2(:, i)]' * realTPos;
    lambdas = inv(-A) * b;
    if lambdas(1,1) <= 0 || lambdas(2, 1) <= 0
        stillPositive = false;
    end
    posLambdas = [posLambdas lambdas];
    i = i + 1;
end
posLambdas % displayed for testing purposes

if stillPositive
    R = RPos;
    T = realTPos;
else 

negLambdas = [];
i = 1;
stillPositive = true;
% Same thing as above, except for the negative versions of computed 
% Rotation matrix and T column. 
while i <= numPoints && stillPositive
    A = [RNeg * cameraCoord1(:, i), -1 * cameraCoord2(:, i)]' * [RNeg * cameraCoord1(:, i), -1 * cameraCoord2(:, i)];
    b = [RNeg * cameraCoord1(:, i), -1 * cameraCoord2(:, i)]' * realTNeg;
    lambdas = inv(-A) * b;
    if lambdas(1,1) <= 0 || lambdas(2, 1) <= 0
        stillPositive = false;
    end
    negLambdas = [negLambdas lambdas];
    i = i + 1;
end
negLambdas % Once again displayed for testing purpose as well as for 
% showing results if right.
if stillPositive
    R = RNeg;
    T = realTNeg;
    THat = TNeg;
else
%     If no solution or both lambdas either way are not positive.
% I just set R and T to -1 and program actually gives an error and have
% it break on purpose.
% I was thinking of just setting it as default to above, but that 
% doesn't seem right so just did this. I was trying to use error function
% but somehow, for my matlab, said it was unrecognized. Othewise I was 
% going to just do that.
    R = [-1 -1 -1];
    T = [-1 -1 -1];
end
end

% These are the results displayed. Pretty self explanatory
actualE
R
T
actualE - (THat * R)

% This is the loop where x2^T * E * x1 is computed for each feature 
% corresponding pair of points and that is displayed at the end as well.
errors = [];
cameraCoord2 = cameraCoord2';
for i=1:numPoints
error = cameraCoord2(i,:) * actualE * cameraCoord1(:, i);
errors = [errors; error];
end
errors
end